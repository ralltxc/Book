package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;

public class insertUserServlet extends HttpServlet{

	@Override
	protected void service(HttpServletRequest request , HttpServletResponse response ) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		int flag=UserDao.insertUser(username, password);
		if(flag==1){
			response.sendRedirect("list");
		}else {
			request.setAttribute("error", "�û����Ѵ���");
			request.getRequestDispatcher("insertUser.jsp").forward(request, response);
		}
	}
	
}
