package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;

public class deleteUserServlet extends HttpServlet{

	@Override
	protected void service(HttpServletRequest request , HttpServletResponse response ) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		
		Integer id = Integer.parseInt(request.getParameter("id"));
		Integer flag=UserDao.deleteUserPWD(id);
		
		if(flag==1){
			response.sendRedirect("list");
		}else {
			request.setAttribute("failed", "系统繁忙，请稍后重试");
			request.getRequestDispatcher("failed.jsp").forward(request, response);
		}
	}
	
}
