package entity;

public class Book {
		private String ISBN;
		private int typeid;
		private String bookname;
		private String author;
		private String publish;
		private String publishdate;
		private String printtime;
		private String unitprice;
		private String typename;
		
		@Override
		public String toString(){
			return "User[ISBN="+ISBN+",typeid="+typeid+","
					+ "bookname="+bookname+",author="+author+","
							+ "publish="+publish+",publishdate="+publishdate+","
									+ "printtime="+printtime+",unitprice="+unitprice+","
											+ "typename="+typename+"]";
		}

		public String getISBN() {
			return ISBN;
		}

		public void setISBN(String iSBN) {
			ISBN = iSBN;
		}

		public int getTypeid() {
			return typeid;
		}

		public void setTypeid(int typeid) {
			this.typeid = typeid;
		}

		public String getBookname() {
			return bookname;
		}

		public void setBookname(String bookname) {
			this.bookname = bookname;
		}

		public String getAuthor() {
			return author;
		}

		public void setAuthor(String author) {
			this.author = author;
		}

		public String getPublish() {
			return publish;
		}

		public void setPublish(String publish) {
			this.publish = publish;
		}

		public String getPublishdate() {
			return publishdate;
		}

		public void setPublishdate(String publishdate) {
			this.publishdate = publishdate;
		}

		public String getPrinttime() {
			return printtime;
		}

		public void setPrinttime(String printtime) {
			this.printtime = printtime;
		}

		public String getUnitprice() {
			return unitprice;
		}

		public void setUnitprice(String unitprice) {
			this.unitprice = unitprice;
		}

		public String getTypename() {
			return typename;
		}

		public void setTypename(String typename) {
			this.typename = typename;
		}
}
