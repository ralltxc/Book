package entity;

public class Booktype {
	private String typeid;
	private String typename;
	
	@Override
	public String toString(){
		return "User[typeid="+typeid+",typename="+typename+"]";
	}

	public String getTypeid() {
		return typeid;
	}

	public void setTypeid(String typeid) {
		this.typeid = typeid;
	}

	public String getTypename() {
		return typename;
	}

	public void setTypename(String typename) {
		this.typename = typename;
	}
	
}
