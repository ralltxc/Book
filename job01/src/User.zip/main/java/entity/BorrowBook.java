package entity;

public class BorrowBook {
	private String readerid;
	private String ISBN;
	private String borrowdate;
	private String returndate;
	private int fine;
	
	@Override
	public String toString(){
		return "User[readerid="+readerid+",ISBN="+ISBN+",borrowdate="+borrowdate+","
				+ "returndate="+returndate+",fine="+fine+"]";
	}

	public String getReaderid() {
		return readerid;
	}

	public void setReaderid(String readerid) {
		this.readerid = readerid;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public String getBorrowdate() {
		return borrowdate;
	}

	public void setBorrowdate(String borrowdate) {
		this.borrowdate = borrowdate;
	}

	public String getReturndate() {
		return returndate;
	}

	public void setReturndate(String returndate) {
		this.returndate = returndate;
	}

	public int getFine() {
		return fine;
	}

	public void setFine(int fine) {
		this.fine = fine;
	}
	
}
